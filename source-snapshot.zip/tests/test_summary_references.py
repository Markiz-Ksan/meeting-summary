import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from summary_writer import write_summary_with, grounded_summary

class ReferenceTests(unittest.TestCase):
    def test_short_fact_is_usable_without_long_quote(self):
        self.assertEqual(write_summary_with(lambda _: '[{"summary":"Анна ушла.","sources":[1]}]', 'Анна ушла.'), '• Анна ушла.')

    def test_fabricated_reference_is_rejected(self):
        with self.assertRaises(ValueError):
            write_summary_with(lambda _: '[{"summary":"Анна ушла.","sources":[2]}]', 'Анна ушла.')

    def test_empty_draft_is_retried_without_echoing_transcript(self):
        answers = iter(['[]', '[{"summary":"Дату пока не определили.","sources":[1]}]'])
        result = write_summary_with(lambda _: next(answers), 'Дату пока не определили.')
        self.assertEqual(result, '• Дату пока не определили.')

    def test_count_check_cannot_become_quality_check_in_reverse_word_order(self):
        with self.assertRaises(ValueError):
            grounded_summary(json.dumps([{'summary':'Всего 72 изделия. Изделия проверены.', 'evidence':'Всего 72 изделия, это уже проверили.'}]), 'Всего 72 изделия, это уже проверили.')

    def test_negative_qualification_cannot_be_omitted_by_citing_positive_sentence(self):
        raw = '[{"summary":"Стоимость услуги 250 евро.","sources":[1]}]'
        with self.assertRaises(ValueError):
            write_summary_with(lambda _: raw, 'Стоимость услуги 250 евро. Курс пока не выбрали.')

    def test_executor_is_not_confused_with_capitalized_first_word(self):
        raw = '[{"summary":"Олег завтра утром проверит резервную копию.","sources":[1]}]'
        self.assertIn('Олег', write_summary_with(lambda _:raw, 'Проверку сделает Олег завтра утром.'))

    def test_historical_negative_does_not_need_to_be_reintroduced_after_reversal(self):
        raw = '[{"summary":"Решение изменили: публикуют базовый тариф.","sources":[2]}]'
        result = write_summary_with(lambda _:raw, 'Вчера договорились не публиковать цены. Сегодня решение изменили: публикуем базовый тариф.')
        self.assertNotIn('не публиковать',result)

    def test_unsupported_quality_attachment_is_removed_without_transcript_fallback(self):
        raw = '[{"summary":"Всего 72 изделия, которые уже проверили.","sources":[1]}]'
        self.assertEqual(write_summary_with(lambda _:raw, 'Всего 72 изделия, это уже проверили.'), '• Всего 72 изделия.')

    def test_removing_quality_only_claim_cannot_manufacture_a_count(self):
        raw = '[{"summary":"Изделия проверены.","sources":[1]}]'
        with self.assertRaises(ValueError):
            write_summary_with(lambda _:raw, 'Всего 72 изделия, это уже проверили.')

    def test_second_causal_link_between_different_events_is_rejected(self):
        raw = '[{"summary":"Прототип обсудят завтра, так как работу не начали из-за отсутствия оценки.","sources":[1,2]}]'
        with self.assertRaises(ValueError):
            write_summary_with(lambda _:raw, 'Прототип обсудят завтра. Работу не начали: оценки нет.')

    def test_short_empty_twice_gets_one_smaller_neural_task(self):
        replies = iter(['[]','[]','{"summary":"Назван срок — май.","evidence":"Срок май."}'])
        self.assertEqual(write_summary_with(lambda _: next(replies), 'Срок май.'), '• Назван срок — май.')

    def test_short_repair_cannot_invent_a_specific_event(self):
        replies = iter(['[]','[]','{"summary":"Релиз утверждён на май.","evidence":"Релиз утверждён на май."}'])
        with self.assertRaises(ValueError):
            write_summary_with(lambda _: next(replies), 'Срок май.')

    def test_tests_genitive_does_not_mean_test_dataset(self):
        raw = '[{"summary":"Релиз отменили из-за тестов авторизации.","sources":[1]}]'
        self.assertIn('Релиз',write_summary_with(lambda _:raw,'Релиз отменили из-за тестов авторизации.'))
        raw = '[{"summary":"Релиз отменили из-за тестирования авторизации.","sources":[1]}]'
        self.assertIn('Релиз',write_summary_with(lambda _:raw,'Релиз отменили из-за тестов авторизации.'))

    def test_executor_name_can_change_grammatical_case(self):
        raw = '[{"summary":"Смета будет отправлена Анной завтра.","sources":[1]}]'
        self.assertIn('Анной',write_summary_with(lambda _:raw,'Смету Анна пришлёт завтра.'))
        raw = '[{"summary":"Резервная копия будет проверена Олегом завтра.","sources":[1]}]'
        self.assertIn('Олегом',write_summary_with(lambda _:raw,'Копию проверит Олег завтра.'))
