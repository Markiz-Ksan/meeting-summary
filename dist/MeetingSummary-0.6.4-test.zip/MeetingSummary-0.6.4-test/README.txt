Meeting Summary 0.6.4 build 11 — private test snapshot.
Contains the existing signed app and matching workers. Python, dependencies and models must be installed separately. See docs/SETUP.md in the project source. Not Apple-notarized. No user meetings or credentials are included.
